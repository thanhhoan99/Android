package com.example.sqlite

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var helper=UserDB(applicationContext)
        val db=helper.readableDatabase
        var rs=db.rawQuery("SELECT * FROM USERS",null)

        if(rs.moveToFirst())
            Toast.makeText(applicationContext,rs.getString(1),Toast.LENGTH_SHORT).show()
        val btnADD = findViewById<Button>(R.id.btnADD)
        val edtUser = findViewById<EditText>(R.id.edtUser)
        val edtPWD = findViewById<EditText>(R.id.edtPWD)
        btnADD.setOnClickListener{
            var cv=ContentValues()
            cv.put("UNAME",edtUser.text.toString())
            cv.put("PWD",edtPWD.text.toString())
            db.insert("USERS",null,cv)
            Toast.makeText(applicationContext,"add thành công",Toast.LENGTH_SHORT).show()
            edtUser.setText("")
            edtPWD.setText("")
            edtUser.requestFocus()
        }
    }
}