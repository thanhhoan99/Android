package com.example.sqlite
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
class UserDB(context:Context)  : SQLiteOpenHelper(context,"USEDB",null,1) {
    override fun onCreate(p0: SQLiteDatabase?) {
//     tạo bảng
   p0?.execSQL("CREATE TABLE USERS(USERID Integer PRIMARY KEY AUTOINCREMENT,UNAME TEXT,PWD TEXT) ")
    p0?.execSQL("INSERT INTO USERS(UNAME,PWD) VALUES ('htht@gmail.com','123212')")
    p0?.execSQL("INSERT INTO USERS(UNAME,PWD) VALUES ('htssht@gmail.com','123212')") }
    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int)
    { TODO("Not yet implemented") }
}