package com.example.roomgk

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.roomgk.adapter.UserAdapter

import com.example.roomgk.data.AddDatabase
import com.example.roomgk.data.entity.User

class EditorActivity : AppCompatActivity() {
    private lateinit var fullName: EditText
    private lateinit var email: EditText
    private lateinit var phone: EditText
    private lateinit var btnSave: Button
    private lateinit var btnAdd: Button
    private lateinit var database: AddDatabase
    private var list = mutableListOf<User>()
    private lateinit var adapter: UserAdapter

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        fullName=findViewById(R.id.full_name)
        email=findViewById(R.id.email)
        phone=findViewById(R.id.phone)
        btnSave=findViewById(R.id.btn_save)
        btnAdd=findViewById(R.id.btn_add)

        database =AddDatabase.getInstance(applicationContext)
//        database = AddDatabase.getInstance(applicationContext)
        adapter = UserAdapter(list)

        val intent=intent.extras
        if (intent!=null){
            val id =intent.getInt("id")
            val user=database.userDao().get(id)
            fullName.setText(user.full_name)
            email.setText(user.email)
            phone.setText(user.phone)

        }

        btnSave.setOnClickListener{
            if(fullName.text.isNotEmpty() && email.text.isNotEmpty() && phone.text.isNotEmpty()){
                if (intent!=null){
                    database.userDao().update(
                        User(
                            intent.getInt("id",0),
                            fullName.text.toString(),
                            email.text.toString(),
                            phone.text.toString()
                        )
                    )
                }else{
                database.userDao().insertAll(
                    User(
                        null,
                        fullName.text.toString(),
                        email.text.toString(),
                        phone.text.toString()
                    )
                )}
                finish()
            }else{
                Toast.makeText(applicationContext,"Save failed", Toast.LENGTH_SHORT).show()
            }
        }
//        btnAdd.setOnClickListener {
//            if(fullName.text.isNotEmpty() && email.text.isNotEmpty() && phone.text.isNotEmpty()){
//
//                    database.userDao().insertAll(
//                        User(
//                            null,
//                            fullName.text.toString(),
//                            email.text.toString(),
//                            phone.text.toString()
//
//                        )
//                    )
//
//                }
//            finish()
//            Toast.makeText(applicationContext,"Save ", Toast.LENGTH_SHORT).show()
//        }


        btnAdd.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            Toast.makeText(applicationContext,"Save ", Toast.LENGTH_SHORT).show()
        }
    }


}